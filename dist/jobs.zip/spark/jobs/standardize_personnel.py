import pandas as pd
from pathlib import Path
import sys

def explore_participation(year: int = 2024):
    """Explore participation data structure."""
    file_path = Path(f"data/raw/participation_{year}.parquet")
    
    if not file_path.exists():
        print(f"❌ File not found: {file_path}")
        print("Run extract_nflfastr.py first to download the data.")
        return
    
    print(f"\n{'='*60}")
    print(f"PARTICIPATION DATA ({year})")
    print(f"{'='*60}\n")
    
    df = pd.read_parquet(file_path)
    
    print("\n" + "-"*60)
    print("Personnel groupings sample:")
    print("-"*60)
    
    if 'offense_personnel' in df.columns:
        print("\nOffensive personnel distribution:")
        print(df['offense_personnel'].value_counts().head(10))
    
    if 'defense_personnel' in df.columns:
        print("\nDefensive personnel distribution:")
        print(df['defense_personnel'].value_counts().head(10))
    
    print("\n" + "-"*60)
    print("Sample player data (semicolon-delimited):")
    print("-"*60)
    
    df["defense_personnel"].printSchema()
    
    return df

def main():
    """Run all exploration functions."""
    print("\n" + "🏈"*30)
    print("NFL DATA EXPLORATION")
    print("🏈"*30)
    
    # Explore each data type
    explore_participation(2024)
    
    print("\n" + "="*60)
    print("✅ Exploration complete!")
    print("="*60)


if __name__ == "__main__":
    main()